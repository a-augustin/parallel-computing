#ifndef _2DCONVOLUTION_H_
#define _2DCONVOLUTION_H_

// Define size of matrix and convolution kernel
#define MATRIX_SIZE 2048
#define KERNEL_SIZE 5

// Thread block dimension
#define TILE_SIZE 12
#define BLOCK_SIZE (TILE_SIZE + 4)

// Matrix Structure declaration
typedef struct {
    unsigned int width;
    unsigned int height;
    float* elements;
} Matrix;

#endif // _2DCONVOLUTION_H_

