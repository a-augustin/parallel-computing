#include <stdlib.h>

extern "C" void compute_gold(float*, const float*, const float*, unsigned int, unsigned int);

/* P = N convolved with M */
void compute_gold(float* P, const float* M, const float* N, unsigned int height, unsigned int width)
{
	/* Calculate convolved value for each element in the result matrix */
	for (unsigned int i = 0; i < height; ++i){
        for (unsigned int j = 0; j < width; ++j) {
			double sum = 0;
			// Check start and end values of M and N to prevent overrunning matrix edges
			unsigned int mbegin = (i < 2)? 2 - i : 0;
			unsigned int mend = (i > (height - 3))? height - i + 2 : 5;
			unsigned int nbegin = (j < 2)? 2 - j : 0;
			unsigned int nend = (j > (width - 3))? (width - j) + 2 : 5;
			// Overlay M over N centered at element (i,j).  For each overlapping element, multiply the two and accumulate
			for(unsigned int m = mbegin; m < mend; ++m) {
				for(unsigned int n = nbegin; n < nend; n++) {
					sum += M[m * 5 + n] * 
							N[width * (i + m - 2) + (j + n - 2)];
				}
			}

			// Store result
			P[i * width + j] = (float)sum;
        }
	}
}

